package weather.nmc.pop.fc;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ucar.nc2.Dimension;
import ucar.nc2.NetcdfFile;
import ucar.nc2.dt.GridDatatype;
import ucar.nc2.dt.grid.GridDataset;
import ucar.unidata.geoloc.LatLonPointImpl;
import ucar.unidata.geoloc.LatLonRect;

/**
 * @author kingboy
 * grib2��ֵ
 */
public class Test2 {

	private float[] lat = null;
	
	private float[] lon = null;
	
	private float[] latng = null;
	
	private float[] lonng = null;
	
	private double[] time = null;
	
	private float[] source = null;
	
	private float[] data = null;
	
	private int lonRange = 0;
	
	private int latRange = 0;
	
	private int timeRange = 0;
	
	private int[] dimsLen = null;
	
	private int sourceLatRange = 0;
	
	private int sourceLonRange = 0;
	
	private int ratio = 1;
	
	private float startLat = 0.0F;
	
	private float startLon = 0.0F;
			
	private float endLat = 0.0F;
	
	private float endLon = 0.0F;	
	
	private float latLonStep = 0.01F;
	
	private boolean isDebug = true;
	/**
	 * @param args
	 * @throws Exception 
	 */
	@SuppressWarnings("unused")
	public static void main(String[] args) throws Exception {
		Test2 ng = new Test2();
	}
		Test2() throws Exception{
		
		startLat = 0;//36;
		
		startLon = 70;//114;
		
		endLat = 60;//42;
				
		endLon = 140;//118;
		
		ratio = 5;//114-118��36-42
		GridDataset gds = ucar.nc2.dt.grid.GridDataset.open("GDFS_NMC_AMEL_QPF_R03_ACHN_LNO_G005_20160611080007203.GRB2");
		GridDatatype grid = gds.findGridDatatype("Total_precipitation_surface_3_Hour_Accumulation");
		GridDatatype subGrid = grid.makeSubset(null, null, new LatLonRect(new LatLonPointImpl(startLat,startLon),new LatLonPointImpl(endLat,endLon)), 1, 1, 1);
		System.out.println("subGrid=>"+subGrid.readVolumeData(0).getSize()+"=>"+Arrays.toString(subGrid.readVolumeData(0).getShape()));
		int gridRank = grid.getRank();
		System.out.println("gridRank=>"+gridRank);
		System.out.println("gridShape=>"+Arrays.toString(grid.getShape()));
		 
//		for(int i=0;i<dimList.size();i++){
//			dimsLen[i] = dimList.get(i).getLength();
//			//System.out.println(((float[])grid.readVolumeData(i).copyTo1DJavaArray()).length);
//		}
		System.out.println("dimsLen=>"+Arrays.toString(dimsLen));
		
		lat = (float[])gds.getNetcdfDataset().findVariable("lat").read().copyTo1DJavaArray();
		
		sourceLatRange = subGrid.getDimension(subGrid.getYDimensionIndex()).getLength();
		
		LatLonRect latLonRect = gds.getBoundingBox();
		
		latLonStep = (float)(Math.round((latLonRect.getWidth())/(lat.length - 1)/ratio*100))/100;
		
		latRange = ratio * (sourceLatRange - 1) + 1;
		
		lon = (float[])gds.getNetcdfDataset().findVariable("lon").read().copyTo1DJavaArray();
		
		sourceLonRange = subGrid.getDimension(subGrid.getXDimensionIndex()).getLength();
		
		lonRange = ratio * (sourceLonRange - 1) + 1;
		
		latng = new float[latRange];
		
		for(int i = 0; i<latRange;i++ ){
			latng[i] = lat[0] + i*latLonStep;//0.01F
		}
		
		lonng = new float[lonRange];
		for(int i = 0; i<lonRange;i++ ){
			lonng[i] = lon[0] + i*latLonStep;//0.01F
		}
		
		System.out.println("latLonStep=>"+latLonStep);
		
		time = (double[])gds.getNetcdfDataset().findVariable("time").read().copyTo1DJavaArray();
		
		timeRange = time.length;
		//source = new float[time.length*lat.length*lon.length];
		System.out.println("timeRage => "+timeRange+" latRange => "+ latRange + " lonRange => "+lonRange);
		data = new float[timeRange * latRange * lonRange];
		
		
		//��ȡԭʼ����
		
		source = (float[])subGrid.readDataSlice(-1, -1, -1, -1).copyTo1DJavaArray();
		
		System.out.println("source len=>"+source.length);
		
		BufferedWriter pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("source.txt")));
		for(int time=0;time<timeRange;time++){
			pw.append("time = "+this.time[time]);
			pw.newLine();
			for(int lat=0;lat<sourceLatRange;lat++){
				for(int lon =0;lon < sourceLonRange;lon++){
					pw.append(String.format("%.2f ", data[getIndex(time, lat,lon)]));
				}
				pw.newLine();
			}	
			pw.newLine();
		}
		
		pw.close();		
		pw = null;
//		for(int i=0;i<source.length;i++){
//			
//		}
		
		//���Ĭ�����ݣ�����ԭʼ���ݽ���
		Arrays.fill(data,-9.0F);
//		List<Integer> indexs = new ArrayList<Integer>();
//		List<Integer> indexs2 = new ArrayList<Integer>();
		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("log.txt")));
		
		for(int time=0;time<timeRange;time++){
			for(int lat=0; lat< sourceLatRange;lat++){
				for(int lon =0;lon < sourceLonRange ;lon++ ){
					int sindex = getIndex(time, lat, lon);
					int dindex = getDataIndex(time, ratio*lat, ratio*lon);
						pw.append("time = "+time+" lat = "+lat+" lon = "+ lon+" sindex = "+sindex+" dindex = "+dindex);
						data[dindex] = source[sindex];
						pw.newLine();
//						indexs.add(sindex);	
//						indexs2.add(dindex);	

				}
			}			
		}
		pw.close();	
		pw = null;
//		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("soureArray.txt")));
//		for(int time=0;time<timeRange;time++){
//			pw.append("time = "+this.time[time]);
//			pw.newLine();
//			for(int lat=0;lat<sourceLatRange;lat++){
//				for(int lon =0;lon < sourceLonRange;lon++){
//					pw.append(String.format("%.2f ", source[getIndex(time, lat,lon)]));
//				}
//				pw.newLine();
//			}	
//			pw.newLine();
//		}
//		
//		pw.close();	
//		pw = null;			
//		System.out.println("indexs=>"+indexs.subList(0,100));
//		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("copyindex.txt")));
//		pw.append(indexs.toString());
//		pw.close();	
//		pw = null;	
//		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("copyindex2.txt")));
//		pw.append(indexs2.toString());
//		pw.close();	
//		pw = null;			
//		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("copysource.txt")));
//		for(int time=0;time<timeRange;time++){
//			pw.append("time = "+this.time[time]);
//			pw.newLine();
//			for(int lat=0;lat<latRange;lat++){
//				for(int lon =0;lon < lonRange;lon++){
//					pw.append(String.format("%.2f ", data[getDataIndex(time, lat,lon)]));
//				}
//				pw.newLine();
//			}	
//			pw.newLine();
//		}
//		
//		pw.close();	
//		pw = null;
		//ͳ�Ƹ���ԭʼ�������
		int sourceCount = 0;
		int emptyCount = 0;
//		indexs.clear();
		for(int i= 0;i<data.length;i++){
			if(data[i]==-9.0F){
				emptyCount++;
			}else{
				sourceCount++; 
				//indexs.add(i);
			}
		}
//		System.out.println(indexs.subList(0,100));
		System.out.println("sourceCount=>"+sourceCount+" emptyCount=>"+emptyCount+" total=>"+data.length +" totalCount=>"+(data.length) +" data[0]=>"+data[0]);
		//γ������
		System.out.println("lat array=>"+Arrays.toString(lat));
		//��������
		System.out.println("lon array=>"+Arrays.toString(lon));
		//ʱ������
		System.out.println("time array=>"+Arrays.toString(time));		
		//���Ȳ�ֵ
		//float startLat = subGrid
		int countcc = 0;
		for(int time=0;time<timeRange;time++){
			//
			for(int lat=0;lat<sourceLatRange;lat++){
				for(int lon =0;lon < sourceLonRange - 1;lon++){
					int index = getIndex(time, lat, lon);
					int index2 = getIndex(time, lat, lon+1);
					float lon1 = this.lon[lon];
					float lon2 = this.lon[lon+1];
					float f1 = source[index];
					float f2 = source[index2];
					int dataBaseIndex = getDataIndex(time, ratio*lat, ratio*lon);//sourceIndex2DataIndex(time, lat, lon);
					//��ֵ
					for(int offset = 1; offset < ratio ;offset++){
						float lonx = lon1 + offset * 0.01F;
						data[dataBaseIndex+offset] = czByDoubleLine(lon1,lon2,lonx,f1,f2);
					}
					//
//					if(lat<20){
//						int index_ = getIndex(time, lat, lon);
//						int index2_ = getIndex(time, lat+1, lon);
//						float lat1 = this.lat[lat];
//						float lat2 = this.lon[lat+1];
//						float f1_ = source[index_];
//						float f2_ = source[index2_];
//						int dataBaseIndex_ = getDataIndex2(time, ratio*lat, ratio*lon);//sourceIndex2DataIndex(time, lat, lon);
//						//��ֵ
//						for(int offset = 1; offset <= 4 ;offset++){
//							float latx = lat1 + offset * 0.01F;
//							data[dataBaseIndex_+offset] = czByDoubleLine(lat1,lat2,latx,f1_,f2_);
//						}						
//					}
				}
			}			
		}	
		//���Ȳ�ֵ

//		for(int time=0;time<1;time++){
//			for(int lat=0;lat<latRange;lat=lat+ratio){
//				for(int lon =0;lon < 6996 ;lon=lon+ratio ){
//					int index = getDataIndex(time, lat, lon);
//					int index2 = getDataIndex(time, lat, lon+ratio);
//					float lon1 = this.lon[lon/ratio];
//					float lon2 = this.lon[lon/ratio + 1];
//					float f1 = data[index];
//					float f2 = data[index2];
//					//���Ȳ�ֵ
//					for(int offset = 1; offset <= 4 ;offset++){
//						float lonx = lon1 + offset * 0.01F;
//						data[index+offset] = czByDoubleLine(lon1,lon2,lonx,f1,f2);
//						countcc++;
//					}
//				}
//			}			
//		}		
//		System.out.println("countcc=>"+countcc);
//		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("londata.txt")));
//		for(int time=0;time<timeRange;time++){
//			pw.append("time = "+this.time[time]);
//			pw.newLine();
//			for(int lat=0;lat<latRange;lat++){
//				for(int lon =0;lon < lonRange;lon++){
//					pw.append(String.format("%.2f ", data[getDataIndex(time, lat,lon)]));
//				}
//				pw.newLine();
//			}	
//			pw.newLine();
//		}
//		
//		pw.close();	
//		pw = null;
		//ͳ�ƾ��Ȳ�ֵ��Ϻ��������
		sourceCount = 0;
		emptyCount = 0;
//		indexs.clear();
		for(int i= 0;i<data.length;i++){
			if(data[i]==-9.0F){
				emptyCount++;
			}else{
				sourceCount++; 
//				indexs.add(i);
			}
		}
//		System.out.println(indexs.subList(0,100));
		System.out.println("sourceCount=>"+sourceCount+" emptyCount=>"+emptyCount+" total=>"+data.length +" totalCount=>"+(data.length) +" data[0]=>"+data[0]);		
		for(int time=0;time<timeRange;time++){
			for(int lon =0;lon < sourceLonRange;lon++){
				for(int lat=0;lat<sourceLatRange - 1;lat++){
					int index = getIndex(time, lat, lon);
					int index2 = getIndex(time, lat+1, lon);

					float lat1 = this.lat[lat];
					float lat2 = this.lat[lat+1];
					float f1 = source[index];
					float f2 = source[index2];
//					System.out.println(lat1 + ">"+ lat2);
//					System.out.println(f1 + "|"+ f2);
//					System.out.println(index + ","+ index2);					
					int dataBaseIndex = getDataIndex(time, ratio*lat, ratio*lon);//sourceIndex2DataIndex(time, lat, lon);
					for(int offset = 1; offset < ratio ;offset++){
						float latx = lat1 + offset*0.01F;//(float)Math.round(()*100)/100;
						
						data[dataBaseIndex+offset*lonRange] = czByDoubleLine(lat1,lat2,latx,f1,f2);
//						System.out.println(String.format(" lat1 = %s  lat2 = %s  latx = %s f1 = %s f2 = %s r = %s", lat1,lat2,latx,f1,f2,data[dataBaseIndex+offset*lonRange]));
					}
				}
			}			
		}
//		for(int time=0;time<1;time++){
//			for(int lon =0;lon < lonRange;lon = lon+ratio){
//				for(int lat=0;lat<96;lat = lat+ratio){
//					int index = getDataIndex(time, lat, lon);
//					int index2 = getDataIndex(time, lat+ratio, lon);
//					float lat1 = this.lat[lat/ratio];
//					float lat2 = this.lat[lat/ratio + 1];
//					float f1 = data[index];
//					float f2 = data[index2];
//					//γ�Ȳ�ֵ
//					for(int offset = 1; offset <= 4 ;offset++){
//						float latx = lat1 + offset*0.01F;
//						data[index+offset*lonRange] = czByDoubleLine(lat1,lat2,latx,f1,f2);
//					}
//				}
//			}			
//		}		
//		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("latdata.txt")));
//		for(int time=0;time<timeRange;time++){
//			pw.append("time = "+this.time[time]);
//			pw.newLine();
//			for(int lat=0;lat<latRange;lat++){
//				for(int lon =0;lon < lonRange;lon++){
//					pw.append(String.format("%.2f ", data[getDataIndex(time, lat,lon)]));
//				}
//				pw.newLine();
//			}	
//			pw.newLine();
//		}
//		
//		pw.close();	
//		pw = null;		
		sourceCount = 0;
		emptyCount = 0;
//		indexs.clear();
		for(int i= 0;i<data.length;i++){
			if(data[i]==-9.0F){
				emptyCount++;
			}else{
				sourceCount++; 
//				indexs.add(i);
			}
		}
//		System.out.println(indexs.subList(0,100));
		System.out.println("sourceCount=>"+sourceCount+" emptyCount=>"+emptyCount+" total=>"+data.length +" totalCount=>"+(sourceCount+emptyCount) +" data[0]=>"+data[0]);			
		//System.out.println(Arrays.toString(Arrays.copyOf(data, 3000)));
		//�е��ֵ	
//		for(int time=0;time<timeRange;time++){
//			for(int lat=0;lat<latRange - 1;lat++){
//				for(int lon =0;lon < lonRange - ratio;lon++){
//					if( 0 == lat % ratio && 0 == lon % ratio) continue;
//					int index = getDataIndex(time, lat, lon);
//					int index2 = getDataIndex(time, lat, lon+1);
//					float lon1 = this.lonng[lon];
//					float lon2 = this.lonng[lon+ratio];
//					float f1 = data[index];
//					float f2 = data[index2];
//					//�е��ֵ
//					for(int offset = 1; offset < ratio ;offset++){
//						float lonx = lon1 + offset*0.01F;
//						data[index+offset] = czByDoubleLine(lon1,lon2,lonx,f1,f2);
//					}
//				}
//			}			
//		}
		for(int time=0;time<timeRange;time++){
			for(int lat=0;lat<sourceLatRange - 1;lat++){
				for(int lon =0;lon < sourceLonRange - 1;lon++){
					
						float lon1 = this.lon[lon];
						float lon2 = this.lon[lon+1];					

//						System.out.println(lon1 + ">"+ lon2);
//						System.out.println(f1 + "|"+ f2);
//						System.out.println(index + ","+ index2);							
						//�е��ֵ
						for(int offset = 1; offset < ratio ;offset++){
							int dataBaseIndex = getDataIndex(time, ratio*lat+offset, ratio*lon);
							int index = dataBaseIndex;//getIndex(time, lat, lon);
							int index2 = getDataIndex(time, ratio*lat+offset, ratio*(lon+1));//getIndex(time, lat, lon+1);
							float f1 = data[index];
							float f2 = data[index2];							
							//if(dataBaseIndex >= data.length) break;
							for(int offset2 = 1; offset2 < ratio ;offset2++){
								float lonx = lon1 + offset2*0.01F;
								data[dataBaseIndex+offset2] = czByDoubleLine(lon1,lon2,lonx,f1,f2);	
//								System.out.println(String.format(" index = %s lat1 = %s  lat2 = %s  latx = %s f1 = %s f2 = %s r = %s", dataBaseIndex+offset2 ,lon1,lon2,lonx,f1,f2,data[dataBaseIndex+offset2]));								
								
							}

						}					
					}

			}			
		}		
		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("data.txt")));
		for(int time=0;time<timeRange;time++){
			pw.append("time = "+this.time[time]);
			pw.newLine();
			for(int lat=0;lat<latRange;lat++){
				for(int lon =0;lon < lonRange;lon++){
					pw.append(String.format("%.2f ", data[getDataIndex(time, lat,lon)]));
				}
				pw.newLine();
			}	
			pw.newLine();
		}
		
		pw.close();	
		pw = null;		
		sourceCount = 0;
		emptyCount = 0;
//		indexs.clear();
		for(int i= 0;i<data.length;i++){
			if(data[i]==-9.0F){
				emptyCount++;
			}else{
				sourceCount++; 
//				indexs.add(i);
			}
		}
//		System.out.println(indexs.subList(0,100));
		System.out.println("sourceCount=>"+sourceCount+" emptyCount=>"+emptyCount+" total=>"+data.length +" totalCount=>"+(sourceCount+emptyCount) +" data[0]=>"+data[0]);			
//		pw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt")));
//		for(int time=0;time<timeRange;time++){
//			pw.append("time = "+this.time[time]);
//			pw.newLine();
//			for(int lat=0;lat<latRange;lat++){
//				for(int lon =0;lon < 100;lon++){
//					pw.append(String.format("%.2f ", data[getDataIndex(time, lat,lon)]));
//				}
//				pw.newLine();
//			}	
//			pw.newLine();
//		}
//		
//		pw.close();
		
	}
	public int getIndex(int time,int lat,int lon){
		
		return time*sourceLatRange*sourceLonRange + lat*sourceLonRange + lon;
		
	}
	public int sourceIndex2DataIndex(int time,int lat,int lon){
		
		return time *latRange*lonRange + ratio*lat*lonRange  + ratio*lon;
		
	}	
	public int getDataIndex(int time,int lat,int lon){
		
		return time*latRange*lonRange + lat*lonRange + lon;
		
	}
	public int getDataIndex(int index,int offset){
		
		return index + offset;
		
	}	
	
	public float czByDoubleLine(float x1,float x2,float x,float f1,float f2) throws Exception{
		//if(f1 == 9 || f2 ==9) return 9;
		float fm = x2 - x1;
		float result = f1 * (x2 - x)/fm + f2 *(x - x1)/fm;
		if(Float.isNaN(result)){
			throw new Exception("error :"+" x1 = "+x1+" x2 = "+x2+" x = "+x + " f1 = "+f1+" f2 = "+f2);
		}
		return result;
	}
	
	

}
