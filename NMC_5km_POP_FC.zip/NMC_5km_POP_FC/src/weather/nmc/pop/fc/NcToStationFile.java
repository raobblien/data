package weather.nmc.pop.fc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import ucar.ma2.Array;
import ucar.ma2.ArrayFloat;
import ucar.ma2.ArrayShort;
import ucar.ma2.ArrayFloat.D2;
import ucar.nc2.NCdumpW;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;

public class NcToStationFile {

	/**
	 * @author Robin
	 * Ԥ���ļ����飬����վ�㾭γ�Ȼ�ȡ
	 */
	public static void main(String[] args) {
		readNcFile();
	}
	
	static Map<String, BigDecimal[]> map = new HashMap<String, BigDecimal[]>();
	
	static{
		BufferedReader br = null;
		String lineTxt = null;
		try {
			br = new BufferedReader(new FileReader("�����ؼ�վ.csv"));
			while((lineTxt = br.readLine()) != null){
				String []array = lineTxt.split(",");
				String stationId = array[0].trim();
				String lon = array[2].trim();
				String lat = array[3].trim();
				BigDecimal a = new BigDecimal(lon).setScale(2, BigDecimal.ROUND_HALF_UP);
				BigDecimal b = new BigDecimal(lat).setScale(2, BigDecimal.ROUND_HALF_UP);
//				System.out.println(stationId + ":" + a + "-" + b);
//				System.out.println("down!");
				BigDecimal [] bg = new BigDecimal[]{a,b};
				map.put(stationId, bg);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void readNcFile(){
		String varName = "pop";
		String fileName = "20160715r03.nc";
		NetcdfFile ncFile = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHH");
		String dateS = "2016071508";
		
		String path = "C:\\Users\\Robin\\Desktop\\grib2\\nc\\popData\\2016071508.txt";
//		String path = "/home/luobing/nc/StationData.txt";
		BufferedWriter fw = null;
		
		try {
			Date date = sdf.parse(dateS);
			
			ncFile = NetcdfFile.open(fileName);
			Variable v = ncFile.findVariable(varName);
			Variable lat = ncFile.findVariable("lat");
			Variable lon = ncFile.findVariable("lon");
			Variable time = ncFile.findVariable("time");
			Array lonArray = lon.read();
			Array latArray = lat.read();
			Array timeArray = time.read();
			
			fw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path)));
			int count = 0;
			for(String stationId : map.keySet()){
				BigDecimal [] bg = map.get(stationId);
				BigDecimal a = bg[0].subtract(new BigDecimal(lonArray.getFloat(0)));   //����
				BigDecimal b = bg[1].subtract(new BigDecimal(latArray.getFloat(0)));   //γ��
				BigDecimal c = new BigDecimal(0.01).setScale(2, BigDecimal.ROUND_HALF_UP);
				int lonNum = a.divide(c, 0, BigDecimal.ROUND_HALF_UP).intValue();
				int latNum = b.divide(c, 0, BigDecimal.ROUND_HALF_UP).intValue();
				
//				int TimeShape = timeArray.getShape()[0]-1;
				
				for(int i =0;i<24;i++){
//					String timeLength = 0 + ":"+TimeShape;
					String Section = i + ", " + latNum + ", " + lonNum;
					ArrayShort.D3 data = (ArrayShort.D3) v.read(Section);
					
					String ss = String.valueOf(data).trim();
					float s = Float.valueOf(ss);
					String pop = String.valueOf(s / 10);
					
					Calendar calendar=Calendar.getInstance();
					calendar.setTime(date); 
					calendar.add(Calendar.HOUR_OF_DAY, timeArray.getInt(i));
					String newTime = (new SimpleDateFormat("yyyyMMddHH")).format(calendar.getTime());
//					String newTime = sdf.format(calendar.getTime());
//					System.out.println(s / 10);
					fw.append(stationId);
					fw.append(",");
					fw.append((a.add(new BigDecimal(70.0f))).toString());
					fw.append(",");
					fw.append(b.toString());
					fw.append(",");
					fw.append(newTime);
					fw.append(",");
					fw.append(pop);
					fw.newLine();
				}
				count++;
				System.out.println(count);
			}
			fw.flush();	
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(fw!=null){
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private static String formatstr(String str){
		byte[] strByte = str.trim().getBytes();
		StringBuilder sb = new StringBuilder();
		byte[] testBytes=str.length()>1?str.substring(0,1).getBytes():str.getBytes();
		int len=0;
		if(testBytes.length>=3){
			len= 10-strByte.length*2/3;
		}else if(testBytes.length>=2){
			len= 10-strByte.length;
		}else if(testBytes.length>=1){
			len= 10-strByte.length;
		}else{
			len=10;
		}
		sb.append(str.trim());
		for (int i = 0; i < len; i++) {
			sb.append(" ");
		}
		return sb.toString();
	}

}
