package weather.nmc.pop.fc;

import ucar.nc2.Dimension;
import ucar.ma2.*;
import ucar.nc2.NCdumpW;
import ucar.nc2.NetcdfFile;
import ucar.nc2.NetcdfFileWriter;
import ucar.nc2.Variable;
import ucar.nc2.dt.GridDatatype;
import ucar.nc2.dt.grid.GridDataset;
import ucar.nc2.write.Nc4Chunking;
import ucar.nc2.write.Nc4ChunkingStrategy;
import ucar.unidata.geoloc.LatLonPointImpl;
import ucar.unidata.geoloc.LatLonRect;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Test {

	/**
	 * @param args
	 */
	
	
	static int NX = 100;
	static int NY = 100;
	static int NZ = 24;
	public static void main(String[] args) throws Exception{
//		test();
//		writeNcTest();
//		write3dNcTest();
		readNcTest();
//		DataTest();
		
//		DoubleLineInter();
		
//		ChangeDate();
//		ArraySizeTest();
//		reWriteTest();
//		pointTest();
	}
	
	public static void test(){
		
		float gg = 0.1F;
		
		int tt = 5;
		String j = Integer.toBinaryString(tt);
		System.out.println(j);
		
		int a = Integer.parseInt(j, 2);
		System.out.println(a);
		
	}
	
	public static void writeNcTest(){
		String filename = "simple_xy.nc";
	    NetcdfFileWriter dataFile = null;
	    try {
	    	 dataFile = NetcdfFileWriter.createNew(NetcdfFileWriter.Version.netcdf3, filename);
	    	 Dimension xDim = dataFile.addDimension(null, "x", NX);
	         Dimension yDim = dataFile.addDimension(null, "y", NY);
	         Dimension zDim = dataFile.addDimension(null, "z", NZ);
	         List<Dimension> dims = new ArrayList<Dimension>();
	         dims.add(xDim);
	         dims.add(yDim);
	         dims.add(zDim);
	         Variable dataVariable = dataFile.addVariable(null, "data", DataType.INT, dims);
	         dataFile.create();
//	         ArrayInt.D2 dataOut = new ArrayInt.D2(xDim.getLength(), yDim.getLength());
	         ArrayInt.D3 dataOut = new ArrayInt.D3(xDim.getLength(), yDim.getLength(), zDim.getLength());
	         int i, j,k;
	         for (i = 0; i < xDim.getLength(); i++) {
	           for (j = 0; j < yDim.getLength(); j++) {
	        	   for(k = 0; k<zDim.getLength(); k++){
	        		   dataOut.set(i, j, k, i*j*k);
	        	   }
	           }
	         }
	         dataFile.write(dataVariable, dataOut);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if (null != dataFile)
		        try {
		          dataFile.close();
		        } catch (IOException ioe) {
		          ioe.printStackTrace();
		        }
		}
	}
	
	public static void write3dNcTest(){
		String filename = "simple_xyz.nc";
	    NetcdfFileWriter dataFile = null;
	    try {
	    	dataFile = NetcdfFileWriter.createNew(NetcdfFileWriter.Version.netcdf3, filename);
	    	Dimension xDim = dataFile.addDimension(null, "lat", NX);
	        Dimension yDim = dataFile.addDimension(null, "lon", NY);
	        Dimension zDim = dataFile.addDimension(null, "time", NZ);
//	        Dimension popDim = dataFile.addDimension(null, "pop", NX*NY);
	        List<Dimension> dims_X = new ArrayList<Dimension>();
	        List<Dimension> dims_Y = new ArrayList<Dimension>();
	        List<Dimension> dims_Z = new ArrayList<Dimension>();
	        List<Dimension> dims_Pop = new ArrayList<Dimension>();
	        dims_X.add(xDim);
	        dims_Y.add(yDim);
	        dims_Z.add(zDim);
	        dims_Pop.add(zDim);
	        dims_Pop.add(xDim);
	        dims_Pop.add(yDim);
	        Variable v1 = dataFile.addVariable(null, "lat", DataType.FLOAT,dims_X);
	        Variable v2 = dataFile.addVariable(null, "lon", DataType.FLOAT,dims_Y);
	        Variable v3 = dataFile.addVariable(null, "time", DataType.INT,dims_Z);
	        Variable v4 = dataFile.addVariable(null, "pop", DataType.INT,dims_Pop);
	        
	        dataFile.create();
	        ArrayFloat.D1 data1 = new ArrayFloat.D1(xDim.getLength());
	        ArrayFloat.D1 data2 = new ArrayFloat.D1(yDim.getLength());
	        ArrayInt.D1 data3 = new ArrayInt.D1(zDim.getLength());
	        ArrayFloat.D3 pop = new ArrayFloat.D3(zDim.getLength(), xDim.getLength(), yDim.getLength());
	        for(int i=0;i<xDim.getLength();i++){
	        	for(int j=0;j<yDim.getLength();j++){
	        		for(int k=0;k<zDim.getLength();k++){
	        			data1.set(i, i);
	        			data2.set(j, j);
	        			data3.set(k, k);
	        			pop.set(k, i, j, 0);
	        		}
	        	}
	        }
	        dataFile.write(v1, data1);
	        dataFile.write(v2, data2);
	        dataFile.write(v3, data3);
	        dataFile.write(v4, pop);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if (null != dataFile){
		        try {
		          dataFile.close();
		        } catch (IOException ioe) {
		          ioe.printStackTrace();
		        }
			}
		}
	}
	
	public static void readNcTest(){
		Date date = new Date();
		
		System.out.println(date.getYear());
		String varName = "pop";
		String fileName = "Total_precipitation_surface_3_Hour_Accumulation_201608170800_24003_3.nc";
		NetcdfFile ncFile = null;
		try {
			ncFile = NetcdfFile.open(fileName);
			Variable v = ncFile.findVariable(varName);
			Variable time = ncFile.findVariable("time");
			DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String time1=format.format(date);
			System.out.println("��ʼʱ�䣺"+time1);
			long begin = System.currentTimeMillis(); 
			
			Array data = v.read("0,3500, 3500");
			
			Array timeArray = time.read();
			
			double[] aaa = (double[]) timeArray.copyTo1DJavaArray();
			System.out.println(timeArray.getInt(0));
			
			long end = System.currentTimeMillis();
			Date date1=new Date();
			String time2=format.format(date1);
			System.out.println("����ʱ�䣺"+time2);
			System.out.println("����ʱ�䣺"+(end-begin)+"ms");
			
//			System.out.println(data);
			NCdumpW.printArray(data, varName,System.out, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void DataTest(){
		String varName = "pop";
		String fileName = "test.nc";
		NetcdfFile ncFile = null;
		int time = 1;
		float lat = 31.89f;
		float lon = 114.89f;
		float lat_min = (float) (((int) (lat / 0.05)) * 0.05);
		float lon_min = (float) (((int) (lon / 0.05)) * 0.05);
		
//		float lat_min = 26.15F;
		float lat_max = new BigDecimal(lat_min).add(new BigDecimal(0.05F)).setScale(2,BigDecimal.ROUND_HALF_UP).floatValue();
			
//		float lon_min = 106.1F;
		float lon_max = new BigDecimal(lon_min).add(new BigDecimal(0.05F)).setScale(2,BigDecimal.ROUND_HALF_UP).floatValue(); 
		
		float startLat = 0;   
		float startLon = 70;
		float endLat = 60;
		float endLon = 140;
		
		BigDecimal a = new BigDecimal(lat_min);
		BigDecimal b = new BigDecimal(lat_max);
		BigDecimal c = new BigDecimal(lon_min);
		BigDecimal d = new BigDecimal(lon_max);
		BigDecimal e = new BigDecimal(startLat);
		BigDecimal f = new BigDecimal(startLon);
		
		BigDecimal g = new BigDecimal(lat);
		BigDecimal h = new BigDecimal(lon);
		
		float source[][][];
		
		try {
			GridDataset gds = ucar.nc2.dt.grid.GridDataset.open("GDFS_NMC_AMEL_QPF_R03_ACHN_LNO_G005_20160611080007203.GRB2");
			GridDatatype grid = gds.findGridDatatype("Total_precipitation_surface_3_Hour_Accumulation");
			GridDatatype subGrid = grid.makeSubset(null, null, new LatLonRect(new LatLonPointImpl(startLat,startLon),new LatLonPointImpl(endLat,endLon)), 1, 1, 1);
			source = (float[][][])subGrid.readDataSlice(-1, -1, -1, -1).copyToNDJavaArray();
			
			int latNum_min = (int) (a.subtract(e).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue() / 0.05);
			int latNum_max = latNum_min + 1;
			int lonNum_min = (int) (c.subtract(f).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue() / 0.05);
			int lonNum_max = lonNum_min +1;
			
			int latNum = (int) (g.subtract(e).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue() / 0.01);
			int lonNum = (int) (h.subtract(f).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue() / 0.01);
			
			float Q11 = source[time][latNum_min][lonNum_min];
			float Q12 = source[time][latNum_min][lonNum_max];
			float Q21 = source[time][latNum_max][lonNum_min];
			float Q22 = source[time][latNum_max][lonNum_max];
			System.out.println(Q11 + "-" + Q12 + "-" + Q21 + "-" + Q22);
			float fx = 0.05f;
			float data1 = (lat_max - lat) / fx;
			float data2 = (lat - lat_min) / fx;
			float R1 = data1 * Q11 + data2 * Q21;
			float R2 = data1 * Q12 + data2 * Q22;
			
			float P = (lon_max - lon) / (lon_max - lon_min) * R1 + (lon - lon_min) / (lon_max - lon_min) * R2;
			System.out.println(P);
			
			
			
			ncFile = NetcdfFile.open(fileName);
			Variable v = ncFile.findVariable(varName);
			String key = time+", " + latNum + ", " + lonNum;
			Array data = v.read(key);
			NCdumpW.printArray(data, varName,System.out, null);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static void DoubleLineInter(){   //˫���Բ�ֵ�㷨
		float startLat = 0;   
		float startLon = 70;
		float endLat = 60;
		float endLon = 140;
		
		int time = 1;
		int lat_min = 522;
		int lat_max = 523;
		int lon_min = 721;
		int lon_max = 722;
		float lat_1Km = 26.16f;
		float lon_1Km = 106.11f;
		float lat_5Km_min = 26.15f;
		float lat_5Km_max = 26.20f;
		float lon_5Km_min = 106.1f;
		float lon_5Km_max = 106.15f;
		
		
		try {
			
			GridDataset gds = ucar.nc2.dt.grid.GridDataset.open("GDFS_NMC_AMEL_QPF_R03_ACHN_LNO_G005_20160611080007203.GRB2");
			GridDatatype grid = gds.findGridDatatype("Total_precipitation_surface_3_Hour_Accumulation");
			GridDatatype subGrid = grid.makeSubset(null, null, new LatLonRect(new LatLonPointImpl(startLat,startLon),new LatLonPointImpl(endLat,endLon)), 1, 1, 1);
			float [][][]source = (float[][][])subGrid.readDataSlice(-1, -1, -1, -1).copyToNDJavaArray();

			float fx = lat_5Km_max - lat_5Km_min;
			float Q11 = ValidData(source[time][lat_min][lon_min]);
			float Q21 = ValidData(source[time][lat_min][lon_max]);
			float Q12 = ValidData(source[time][lat_max][lon_min]);
			float Q22 = ValidData(source[time][lat_max][lon_max]);
			
//			if(Q11!=0.0 & Q12!=0.0 & Q21!=0.0 & Q22!=0.0){
//				System.out.println(Q11+"-"+Q12+"-"+Q21+"-"+Q22);
//			}
//			System.out.println(Q11+"-"+Q12+"-"+Q21+"-"+Q22);
			float data1 = (lat_5Km_max - lat_1Km) / fx;
			
//			System.out.println(fx);
			float data2 = (lat_1Km - lat_5Km_min) / fx;
			float R1 = data1 * Q11 + data2 * Q21;
			float R2 = data1 * Q12 + data2 * Q22;
			float P = (lon_5Km_max - lon_1Km) / (lon_5Km_max - lon_5Km_min) * R1 + (lon_1Km - lon_5Km_min) / (lon_5Km_max - lon_5Km_min) * R2;
			float Data =  (float) (Math.round(P*1000)/1000.000);
			System.out.println(Data);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static float ValidData(float data){   //���ݼ�ֵУ��
		return data>999 ? 0.0F : data;
	}
	
	
	public static void ChangeDate(){
		String path = "C:\\Users\\Robin\\Desktop\\grib2\\nc\\2016070120StationData1.txt";
		String path1 = "C:\\Users\\Robin\\Desktop\\grib2\\nc\\2016070120StationDataNew.txt";
		
		String lineTxt = null;
		BufferedWriter fw = null;
		BufferedReader br = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHH");
		
		try {
			br = new BufferedReader(new FileReader(path));
			fw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path1)));
			while((lineTxt = br.readLine()) != null){
				String[] array = lineTxt.split(",");
				String dateS  = array[3].trim();
				Date date = sdf.parse(dateS);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				cal.add(Calendar.HOUR_OF_DAY, -60);
				String newTime = (sdf.format(cal.getTime()));
				array[3] = newTime;
				fw.append((Arrays.toString(array)).replace("[", "").replace("]", ""));
				fw.newLine();
			}
			fw.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(fw!=null){
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		
		
	}
	
	public static void ArraySizeTest(){
//		System.out.println(new BigDecimal(500).divide(new BigDecimal(3)));
		
		try {
			int timeRange = 150;
			int latRange = 6001;
			int lonRange = 7001;
			
			BigDecimal a = new BigDecimal(timeRange);
			BigDecimal b = new BigDecimal(latRange);
			BigDecimal c = new BigDecimal(lonRange);
			
			BigDecimal d = a.multiply(b).multiply(c);
			BigDecimal e = new BigDecimal(Integer.MAX_VALUE);
			int count =1;
			while(e.compareTo(d)<0){
				count++;
				a = a.divide(new BigDecimal(count),0,BigDecimal.ROUND_HALF_UP);
				d = a.multiply(b).multiply(c);
				
			}
			
			int realTime = a.intValue();
			int realTimeCount = timeRange / realTime;
			
			for(int t=0;t<realTimeCount;t++){
//				short[]as = new short[realTime * (latRange) * (lonRange)];
				if(t>0){  //i>0��ʾ�ļ��Ѵ��ڣ���Ҫ���´��ļ���д
					
					for(int i =t*realTime;i<realTime*(t+1);i++){
						System.out.println(i);
					}
				}else{ //i<0��ʾ�ļ��������ڣ��ǵ�һ��д�ļ�
					for(int i =0;i<realTime;i++){
						System.out.println(i);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void reWriteTest(){
		try {
			NetcdfFileWriter writer = null;
		    Nc4Chunking chunker = Nc4ChunkingStrategy.factory(Nc4Chunking.Strategy.standard,5,false);//��������д���ļ������ٶ����
			NetcdfFileWriter.Version version = NetcdfFileWriter.Version.netcdf4;
			writer = NetcdfFileWriter.createNew(version, "ReWriteTest.nc",chunker);
		    Dimension latDim = writer.addDimension(null, "lat", 64);
		    Dimension lonDim = writer.addDimension(null, "lon", 128);
		    List<Dimension> dims = new ArrayList<Dimension>();
		    dims.add(latDim);
		    dims.add(lonDim);
		    Variable t = writer.addVariable(null, "temperature", DataType.DOUBLE, dims);
		    Array data = Array.factory(int.class, new int[]{3}, new int[]{1, 2, 3});

		    // add a string-valued variable: char svar(80)
		    Dimension svar_len = writer.addDimension(null, "svar_len", 80);
		    writer.addVariable(null, "svar", DataType.CHAR, "svar_len");

		    // add a 2D string-valued variable: char names(names, 80)
		    Dimension names = writer.addDimension(null, "names", 3);
		    writer.addVariable(null, "names", DataType.CHAR, "names svar_len");

		    // add a scalar variable
		    writer.addVariable(null, "scalar", DataType.DOUBLE, new ArrayList<Dimension>());
		    writer.create();
		    
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	public static void pointTest(){
		float lat_1km = 40.65f;
		float lon_1km = 135.13f;
		
		int lat = (int) Math.round(lat_1km * 100);
		int lon = (int) Math.round(lon_1km * 100)-7000;
		System.out.println(lat);
		System.out.println(lon);
		
		
		
	}
	
	

}
