package weather.nmc.pop.fc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.HashMap;



public class Test3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		changeName();
		

	}
	
	public static void changeName(){
		String path1 = "new.csv";
		
		
		BufferedReader br = null;
		BufferedWriter fw = null;
		String lineTxt = null;
		HashMap<String,String[]> map = new HashMap<String,String[]>();
		try {
			br = new BufferedReader(new FileReader("�����ؼ�վ.csv"));
			while((lineTxt = br.readLine()) != null){
				String []array = lineTxt.split(",");
				String id = array[0].trim();
				String name = array[1].trim();
				String lon = array[2].trim();
				String lat = array[3].trim();
				String [] a = new String[3];
				a[0] = name;
				a[1] = lon;
				a[2] = lat;
				map.put(id,a);
			}
			br.close();
			br = new BufferedReader(new FileReader("plot_blue_sky_tongji.csv"));
			fw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path1)));
			int count =0;
			while((lineTxt = br.readLine()) != null){
				if(count==0){
					count++;
					continue;
				}
				String []array = lineTxt.split(",");
				String id = array[0].trim();
				String name = map.get(id)[0];
				String lat = map.get(id)[2];
				String lon = map.get(id)[1];
				fw.append(Arrays.toString(array).replace("[","").replace("]",""));
				fw.append(",");
				fw.append(name);
				fw.append(",");
				fw.append(lon);
				fw.append(",");
				fw.append(lat);
				fw.newLine();
			}
			fw.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		try{
			
			
			
		}finally{
			
		}
			
		
		
		
	}
	
	/*public static void getStation(){
		
		String path1 = "station.json";
		BufferedReader br = null;
		BufferedWriter fw = null;
		String lineTxt = null;
		HashMap<String,String> map = new HashMap<String,String>();
		
		
		try {
			br = new BufferedReader(new FileReader("�����ؼ�վ.csv"));
			JSONArray jr = new JSONArray();
			while((lineTxt = br.readLine()) != null){
				String []array = lineTxt.split(",");
				String id = array[0].trim();
				String name = array[1].trim();
				String lon = array[2].trim();
				String lat = array[3].trim();
				
				JSONObject jo = new JSONObject();
				jo.put(name, lon+","+lat);
				
				jr.add(jo);
				
			}
			String json = jr.toString();
			
			fw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path1)));
			fw.append(json);
			fw.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}*/

}
